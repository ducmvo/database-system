# Week 9 Breakout Exercise
## Contents
- gradlew/gradlew.bat - These let you build and run your Java application from the command line. There are a number of tasks you can tell Gradle to do; the main one you'll want is `./gradlew run` to run your application. You can always use `./gradlew tasks` to have it tell you what tasks it can do.
- build.gradle.kts - This tells Gradle what libraries to include with your application and what class to run. If you are using IntelliJ, you will want to choose "File" -> "New" -> "Project from existing sources..." and then select this file. IntelliJ will know how to create a project based on this file.
- sample.db - A [SQLite](https://www.sqlite.org) database containing sample data.
- schema.sql - A SQL script file containing the CREATE TABLE statements for all the tables in sample.db.
- src/main/Main.java - A mostly empty Java class that acts as the entry point to the application you will write.

## Data Source
The data contained in sample.db is a subset of what's available from the U.S. Department of Agriculture: https://fdc.nal.usda.gov/download-datasets.html. You can find a list of field descriptions here: https://fdc.nal.usda.gov/portal-data/external/dataDictionary.

## In-Class Assignment
You will be starting a food diary application, to be continued in homework 5. As a group, do the following:

1. Create a Java method that will insert a new row into the `food_journal` 
   table. It should accept arguments for each of the columns. If the provided value for `eaten_at` is null, default to the current time. Make sure to use the correct syntax to ensure that and end user cannot inject SQL statements via the `comment` field.
2. Create a Java method that inserts several sample rows into `food_journal` using the method from step 1.
3. Create a Java method that prints out the description, total amount eaten, and time for the most recent record in `food_journal`. For example, if the most recent record was for 2 of food portion 118707, the method should print something along the lines of "HUMMUS, OTHER: 4 tablespoon at 2021-11-24 10:00:00" (2 portions of 2 tablespoon = 4 tablespoon). The exact formatting is up to you.
