rootProject.name = "cpsc5021-sqlite"

