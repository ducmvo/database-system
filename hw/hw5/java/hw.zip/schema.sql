CREATE TABLE food (
    fdc_id int primary key,
    data_type varchar(64),
    description varchar(255),
    food_category_id int,
    publication_date date
);

CREATE TABLE nutrient (
    id int primary key,
    name varchar(128),
    unit_name varchar(16),
    nutrient_nbr int
);

CREATE TABLE food_nutrient (
    id int primary key,
    fdc_id int not null,
    nutrient_id int not null,
    amount float
);

CREATE TABLE measure_unit (
    id int primary key,
    name varchar(32)
);

CREATE TABLE food_portion (
    id int primary key,
    fdc_id int not null,
    amount float,
    measure_unit_id int,
    modifier varchar(255),
    gram_weight float
);

CREATE TABLE food_journal (
    id int auto_increment primary key,
    food_portion_id int,
    quantity float,
    comment varchar(255),
    eaten_at timestamp
);
